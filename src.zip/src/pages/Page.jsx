import React from "react";

const Page = () => {
  return (
    <div>
      <h1>Не та страница</h1>
      не та ссылка или не тот доступ
    </div>
  );
};

export default Page;
